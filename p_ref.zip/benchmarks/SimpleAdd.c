int main() {

  int a = 3;
  int b = 2;
  int c = 0;

  c = a + b;

  return c;
}
