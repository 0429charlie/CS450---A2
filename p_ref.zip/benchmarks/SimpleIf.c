int main() {

int x = 3;
int y = 2;
int c = 0;


if (x < 5)
	x =  x + y;
else 
	x = x - y;

c = x + y;
return c;
}
